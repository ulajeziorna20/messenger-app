

const Home = () => {
    return ( <div className="Home">
        Home Page
    </div> );
}
 
export default Home;